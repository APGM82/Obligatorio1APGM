class Tierra {
    //matriz de 3x3
        //cada cuadrante tiene espacio para 3 drones
        // espacio para un jack(fila+columna)
        // y una vika(fila+columna)
        //espacio para orden de reparacion
        //espacio para orden de exploracion
}